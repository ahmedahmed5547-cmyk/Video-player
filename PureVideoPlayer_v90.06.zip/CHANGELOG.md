# Changelog — IPTV and Video player (`com.pureplayer.video`)

This Changelog permanently retains and displays **only the latest 3 versions** of **IPTV and Video player**. When a new version is released, the new version is added at the top, the previous two versions are kept, and the oldest version is automatically removed.

## [v90.06] - 2026-11-18 (`versionCode = 9006`) — Restore Stable Section-Specific Instant Search & 3-Version Changelog
- **Restored Original IPTV Search System:** Reverted the experimental `v90.05` search engine additions and restored the fast, stable search implementation (`IptvSearchNormalizer` + `IptvRepository.searchStreamsSql`) from the verified baseline.
- **Strict Section-Specific Search (`SectionScopedSearchHelper`):** Restricted IPTV search exclusively to the section currently being viewed — searching inside **Movies** returns only Movies, searching inside **TV Series** returns only TV Series, and searching inside **Live TV** returns only Live TV, never mixing results from other sections.
- **Instant Live Results While Typing:** Removed the `280ms` debounce delay and `distinctUntilChanged` bottleneck so search results update immediately from the very first character and with every subsequent keystroke without pressing Enter.
- **3-Version Rolling Changelog (`ChangelogVersionManager`):** Updated both the in-app Changelog (`SettingsMenus.kt`) and `CHANGELOG.md` to permanently retain and display only the latest 3 versions (`v90.06`, `v90.05`, `v90.04`).

## [v90.05] - 2026-11-18 (`versionCode = 9005`) — Android Keyboard Viewport Resize & Layout Adjustment
- **On-Screen Keyboard Compatibility (`adjustResize` & `WindowInsetsCompat.Type.ime()`):** Configured `MainActivity` to dynamically adjust the results list bottom padding and viewport height when the Android keyboard opens or closes so search results are not hidden behind the keyboard.

## [v90.04] - 2026-11-18 (`versionCode = 9004`) — IPTV Auto-Sync, Responsive Multi-Device UI & Rebranding
- **Application Name Change (`IPTV and Video player`):** Renamed the application consistently across the launcher, main toolbar, Settings, About section, and Privacy Policy to **IPTV and Video player**.
- **Automatic IPTV Background Sync (`IptvSessionSyncGuard`):** Added session-scoped automatic background refresh when opening the main IPTV section with a subtle 3dp top progress bar (`iptvSubtleSyncBar`), while preserving cached data without re-syncing during internal navigation or scrolling across Movies, TV Series, and Live TV.
- **Settings Deduplication & Responsive Multi-Device Design:** Removed the duplicate Sort & Layout option from Settings (keeping it exclusively in the top 3-line menu) and added adaptive layouts (`ResponsiveUiMetrics`, `sw600dp`, `sw720dp`) for smartphones, tablets, and large screens.
