# Changelog — VEXO Player: IPTV and Video player (`com.pureplayer.video`)

## v90.11 (2026-11-20) — Luxury Dark Redesign, Foldable Support & Core Engineering Fixes
- **Luxury Dark UI/UX & Luxury Gold Theme:** Redesigned Player Settings and Playback UI with `#0A0A0F`/`#12121A` glassmorphism surfaces, hairline borders, thin-line vector icons, dynamic `BuildConfig.VERSION_NAME` version pill, marquee filename, compact subtitle glass pill, glowing SeekBar, tabular monospace timers, and selectable `Luxury Gold (#D4AF37)` theme.
- **Full Foldable & Adaptive Layout Support:** Integrated Jetpack WindowManager (`androidx.window:window:1.3.0`) supporting Flat Unfolded, Folded Cover (Z Fold/Flip), Tabletop (upper video / lower controls), and Book postures with hinge-safe subtitle/control placement and centered max-width dialogs (`580–620dp`).
- **Rotation Controls, VLC Aspect Engine & First-Install Fix:** Rebuilt bottom controls in `ConstraintLayout` with `WindowInsets`/`displayCutout`, ported VLC `changeSurfaceLayout()` (`VlcSurfaceLayoutMath`) eliminating Fit-to-Stretch cropping, and migrated scanning to `VideoLibraryViewModel` (`StateFlow`, `ContentObserver`, `MediaScannerConnection` fallback).
- **Android 15/16 Compliance & 4-Version Changelog:** Enabled `enableEdgeToEdge()`, removed deprecated bar colors and static manifest `screenOrientation`, upgraded to AGP `8.5.1` (Gradle `8.7`) + `libvlc-all:3.6.5` for 16 KB alignment, and updated Changelog display to show the latest 4 releases with full notes.

## v90.10 (2026-11-18) — Google Play Console Release Bundle (`versionCode = 9010`)
- **Fresh Play Console Version Code:** Incremented `versionCode` to `9010` (`versionName = "90.10"`) to resolve Play Console duplicate version code conflict.
- **Embedded Native Debug Symbols:** Configured `ndk { debugSymbolLevel = "FULL" }` for full crash/ANR symbolication inside the `.aab`.

## v90.09 (2026-11-18) — Android 16 (API Level 36) Google Play Target SDK Compliance
- **Target API Level 36 Upgrade:** Upgraded `compileSdk` and `targetSdk` from `34` to `36` (Android 16) to meet Google Play submission policy.
- **Build Compatibility:** Added `android.suppressUnsupportedCompileSdk=36` in `gradle.properties`.

## v90.08 (2026-11-18) — Official `VEXO Player` (`IPTV and Video player`) Store Identity & Privacy Integration
- **Unified Brand Identity:** Adopted primary name `VEXO Player` with secondary subtitle `IPTV and Video player` across toolbar, About dialog, Privacy Policy, and Google Play Store listing assets.
- **Official Developer Contact & Privacy Links:** Integrated developer contact email (`AHMEDAHMED5547@GMAIL.COM`) and public GitHub Privacy Policy URLs across all disclosures.
