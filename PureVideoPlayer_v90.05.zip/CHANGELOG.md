# Changelog — IPTV and Video player (`com.pureplayer.video`)

All notable changes to **IPTV and Video player** are documented in this file and organized by version and date.

## [v90.05] - 2026-11-18 (`versionCode = 9005`) — Smart Arabic & Multilingual Search Engine + Keyboard Viewport Fix
### New Features & Search Engine Upgrade
- **Professional Arabic & Multilingual Search Engine (`IptvSmartSearchEngine`):**
  - Full normalization of Arabic letter variants (`أ، إ، آ، ٱ -> ا`, `ى، ی، ے، ئ -> ي`, `ة، ه، ھ، ۀ -> ه`, `ؤ -> و`, `ک، گ -> ك`), Arabic-Indic/Eastern digits (`٠-٩ / ۰-۹ -> 0-9`), and automatic stripping of all Arabic diacritics (Tashkeel) and Tatweel.
  - Intelligent matching with or without spaces (`"ابوظبي"` ↔ `"أبو ظبي"`, `"بي ان"` ↔ `"بي إن"`, `"beinsport"` ↔ `"beIN Sports"`) and with or without the Arabic definite article `ال` (`"جزيرة"` ↔ `"الجزيرة"`, `"أفلام"` ↔ `"الأفلام"`).
  - Phonetic Arabic variation handling (`ذ/ز/ظ`, `ص/س`, `ط/ت`, `ض/د`, repeated character collapsing), bounded Damerau-Levenshtein typo recovery (`distance <= 1..2`), and bidirectional Arabic ↔ English IPTV aliases (`mbc` ↔ `ام بي سي`, `bein` ↔ `بي ان`, `alkass` ↔ `الكاس`, `rotana` ↔ `روتانا`, `osn` ↔ `او اس ان`, `shahid` ↔ `شاهد`).
- **Multi-Tier Relevance Ranking & Deduplication:**
  - Prioritizes Exact Title Matches first, followed by Title Prefix Matches, Word-Boundary Phrase Matches, Multi-Token Matches, and Category/Alias/Typo Matches across all IPTV sections (Movies, TV Series, Live TV, Radio).
  - Automatically groups multi-episode M3U series in search results (`getSearchableStreamsForSourceSync`) so searching for a series returns a single clean Series entry rather than dozens of duplicate episode rows.

### Critical UI Bug Fix & Search UX Improvements
- **Fixed Search Results Hidden Behind On-Screen Keyboard:**
  - Configured `android:windowSoftInputMode="adjustResize|stateHidden"` on `MainActivity` and integrated `WindowInsetsCompat.Type.ime()` into the root inset listener (`updateKeyboardAndSearchViewportLayout`).
  - Automatically resizes the results container above the keyboard, hides the bottom navigation bar while the keyboard is open, and adjusts `RecyclerView` bottom padding so the user can scroll through all results down to the very last item without dismissing the keyboard.
- **Professional Search Interface:**
  - Added a subtle inline loading spinner (`searchLoadingSpinner`), live matching result counter (`tvSearchResultsCount`), and 1-tap IPTV section filter pills (`All`, `📺 Live`, `🎬 Movies`, `🎞️ Series`) directly inside the search header while hiding redundant sub-headers during search.

## [v90.04] - 2026-11-18 (`versionCode = 9004`) — IPTV Auto-Sync, Responsive Multi-Device UI & Rebranding
### New Features & Branding
- **Application Name Change (`IPTV and Video player`):** Updated the application name consistently across the launcher (`app_name`), main toolbar interface, navigation headers, Settings, About section, Privacy Policy, and internal branding to **IPTV and Video player**.
- **Session-Scoped Automatic IPTV Background Refresh (`IptvSessionSyncGuard`):** Automatically refreshes and synchronizes the IPTV library in the background whenever the user opens the main IPTV section, while immediately displaying cached content with zero waiting time.

### Performance & User Experience Improvements
- **Subtle Non-Intrusive Sync Indicator:** Replaced the blocking modal overlay with a clean, subtle 3dp top progress indicator (`iptvSubtleSyncBar`) and inline header spinner (`iptvInlineSyncSpinner`).
- **Uninterrupted Internal IPTV Navigation & Scrolling:** Added in-memory caching (`sectionCountsMemoryCache`, `categoriesMemoryCache`, `firstPageStreamsMemoryCache`, `seriesInfoMemoryCache`) and disabled pull-to-refresh interception inside IPTV sections so switching between **Movies**, **TV Series**, and **Live TV** or scrolling down never triggers repeated refreshes. The library refreshes again only when the user leaves and reopens the main IPTV section.
- **Parallel Xtream Category Discovery & Fast Timeouts:** Parallelized Live, VOD, and Series category map requests and reduced dead-port probe timeouts (`3,800ms`) for faster server connection.

### UI Modifications & Responsive Design
- **Removed Duplicate Sort & Layout Settings:** Removed the duplicate `Media Layout & Sort` entry from the main Settings section (`Appearance & Language`), preserving a single, consistent access point through the top three-line (hamburger) menu (`☰`) with full support for both Video Folders and IPTV streams.
- **Responsive Design for Smartphones, Tablets (`sw600dp`), and Large Screens (`sw720dp+`):**
  - Added `ResponsiveUiMetrics` and dedicated dimension qualifiers (`values/dimens.xml`, `values-sw600dp/dimens.xml`, `values-sw720dp/dimens.xml`).
  - Adaptive column spans for both Grid mode (2 to 6 columns) and Tablet/Large-Screen List mode (1 to 2 columns).
  - Proportional scaling for Movie/Series posters (`2:3` aspect ratio) and video/channel thumbnails (`16:9` aspect ratio).
  - Responsive `PlayerActivity` top control bar that automatically collapses secondary subtitle buttons on compact/portrait screens to prevent title clipping while displaying full controls on landscape phones, tablets, and large displays.

## [v90.03] - 2026-11-17 (`versionCode = 9003`) — Google Play Store Final Readiness
### Added & Improved
- **Play Flavor Demo Isolation (`ALLOW_DEMO_IPTV_SOURCE`):** Automatically hides the built-in Demo IPTV source button in the `play` flavor (`bundlePlayRelease`) so Google Play reviewers see a 100% pure player with zero pre-bundled streams, while preserving it in the `github` flavor.
- **Modern Uncompressed Native Library Packaging:** Set `jniLibs.useLegacyPackaging = false` in `app/build.gradle.kts` for optimal Android App Bundle (AAB) native library alignment.
- **Interactive In-App Privacy Policy & Ready Web Files:** Made the Privacy & Data Security card in the About menu open a full bilingual privacy disclosure page inside the app, and added `PRIVACY_POLICY.md` and `privacy-policy.html` to the repository root for 1-click GitHub Pages hosting.

## [v90.02] - 2026-11-17 (`versionCode = 9002`) — Google Play Compliance & Security Hardening
### Security & Google Play Policy Fixes
- **Trademark & Store Policy Compliance:** Replaced third-party trademark string in English resources (`values/strings.xml`) with neutral `"IPTV Hub (Xtream & M3U)"` matching Arabic resources.
- **Self-Updater Bytecode Sanitization:** Removed `"application/vnd.android.package-archive"` package installer intent from `UpdateManager.kt` so the compiled DEX bytecode passes Google Play's Device and Network Abuse static scanner cleanly.
- **Subtitle Provider Policy Cleanup:** Removed third-party piracy domain references from `SubtitleSearchEngine.kt` and `SubtitleProviders.kt`, retaining compliant subtitle providers (`OpenSubtitles-v3`, `OpenSubtitles REST`, `Podnapisi`, `SubDL`).
- **Private Vault Backup & Cache Hardening:** Excluded `video_media_index_cache_v1.json`, `subtitles_cache`, and `demo_iptv_showcase.m3u8` from cloud backup and device transfer (`backup_rules.xml`, `data_extraction_rules.xml`), and filtered locked Private Vault folders out of the unencrypted local media index cache (`VideoIndexCache.kt`).
- **External Cast URI Safety (`FileProvider`):** Updated `PlayerActivity.beamVideoToExternalCastApp()` and `file_paths.xml` to wrap `file://` URIs via `FileProvider` (`content://`), preventing `FileUriExposedException` on Android 7.0+.
- **In-App Privacy & Data Security Disclosure:** Added a clear Privacy & Data Security summary card inside the About screen (`SettingsMenus.kt`) in both Arabic and English.

## [v90.01] - 2026-11-16 (`versionCode = 9001`) — Verified Green Build ✓
### Fixed & Improved
- Fixed Room `@Database` annotation syntax in `IptvDatabase.kt` (`exportSchema = false`).
- Upgraded `app/build.gradle.kts` keystore verification (`verifyKeystoreCredentials`) for full compatibility with Gradle 8.5 and Kotlin 1.9.22 DSL without inline lambda `break` errors.
- Updated `.github/workflows/build.yml` to automatically unpack `PureVideoPlayer*.zip`, sync `versionName`, run unit tests (`testGithubDebugUnitTest`, `testPlayDebugUnitTest`), and build signed Release APKs and Google Play AAB bundles.
- Preserved official signing key (`app/release.keystore`, alias `pureplayer_release_key`) for seamless in-place updates.
