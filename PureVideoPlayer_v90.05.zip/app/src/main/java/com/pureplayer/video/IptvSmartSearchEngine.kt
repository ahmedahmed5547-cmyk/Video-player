package com.pureplayer.video

import java.util.Locale

/**
 * Professional Arabic & Multilingual Smart Search Engine for IPTV (Live TV, Movies, TV Series, Radio)
 * and Local Video Libraries.
 *
 * Key Capabilities:
 * 1. Deep Arabic Normalization:
 *    - Unifies all Alef/Hamza forms (أ، إ، آ، ٱ -> ا), Ya/Alef Maqsura & Farsi Ya (ى، ی، ے -> ي),
 *      Ta Marbuta & Ha variants (ة، ه، ھ، ۀ -> ه), Kaf/Gaf variants (ک، گ -> ك),
 *      and Hamza-on-Waw/Ya (ؤ -> و, ئ -> ي).
 *    - Strips all Arabic Tashkeel/diacritics (\u0610-\u061A, \u064B-\u065F, \u0670, \u06D6-\u06ED),
 *      Tatweel/Kashida (\u0640), and invisible directional marks.
 *    - Converts Arabic-Indic (٠-٩) and Eastern Arabic (۰-۹) digits to ASCII (0-9).
 * 2. Flexible Space, Prefix ("ال"), & Compound-Word Handling:
 *    - Matches queries with or without spaces (e.g., "ابوظبي" <-> "أبو ظبي", "بي ان" <-> "بي إن", "bein sport" <-> "beinsport").
 *    - Matches Arabic words with or without the definite article "ال" (e.g., "جزيرة" <-> "الجزيرة", "أفلام" <-> "الأفلام").
 * 3. Phonetic & Spelling Variation Tolerance + Typo Recovery:
 *    - Handles common Arabic phonetic/orthographic substitutions (ذ/ز/ظ, ض/ظ, س/ص, ت/ط, trailing ء/ا/ه/ي)
 *      and collapses repeated letters.
 *    - Supports bounded Damerau-Levenshtein edit distance (<= 1 for 4..7 char tokens, <= 2 for 8+ char tokens)
 *      so minor typing mistakes never hide valid content.
 *    - Supports bidirectional Arabic <-> English IPTV transliteration aliases (e.g., "mbc" <-> "ام بي سي",
 *      "bein" <-> "بي ان", "alkass" <-> "الكاس", "rotana" <-> "روتانا", "osn" <-> "او اس ان", "shahid" <-> "شاهد").
 * 4. Multi-Tier Relevance Ranking:
 *    - Prioritizes Exact Title Matches -> Title Prefix Matches -> Exact Word/Phrase Matches ->
 *      All-Tokens Title Matches -> Category/Alias Matches -> Phonetic/Typo Matches.
 */
object IptvSmartSearchEngine {

    private val diacriticsAndMarksRegex = Regex(
        "[\\u0610-\\u061A\\u064B-\\u065F\\u0670\\u06D6-\\u06ED\\u0640\\u200B-\\u200F\\u202A-\\u202E\\u2060-\\u206F\\uFEFF]"
    )
    private val punctuationAndSeparatorsRegex = Regex("[^\\p{L}\\p{N}\\s]+")
    private val multiSpaceRegex = Regex("\\s+")
    private val scriptBoundaryRegex = Regex("([\\u0600-\\u06FF])([a-z0-9])|([a-z0-9])([\\u0600-\\u06FF])")

    // Bidirectional Arabic <-> English common IPTV aliases
    private val bilingualAliases: List<Pair<Set<String>, Set<String>>> = listOf(
        setOf("mbc") to setOf("ام بي سي", "امبيسي"),
        setOf("bein", "be in") to setOf("بي ان", "بيان", "بين سبورت"),
        setOf("ssc") to setOf("اس اس سي", "السعوديه الرياضيه"),
        setOf("osn") to setOf("او اس ان", "اوسن"),
        setOf("rotana") to setOf("روتانا"),
        setOf("alkass", "al kass", "kass") to setOf("الكاس", "كاس"),
        setOf("aljazeera", "al jazeera", "jazeera") to setOf("الجزيره", "جزيره"),
        setOf("alarabiya", "al arabiya", "arabiya") to setOf("العربيه", "عربيه"),
        setOf("abudhabi", "abu dhabi", "ad sports") to setOf("ابوظبي", "ابو ظبي"),
        setOf("dubai") to setOf("دبي"),
        setOf("sharjah") to setOf("الشارقه", "شارقه"),
        setOf("kuwait") to setOf("الكويت", "كويت"),
        setOf("oman") to setOf("عمان"),
        setOf("qatar") to setOf("قطر"),
        setOf("nilesat", "nile") to setOf("نايل", "النيل"),
        setOf("shahid") to setOf("شاهد"),
        setOf("netflix") to setOf("نتفلكس", "نتفليكس"),
        setOf("watchit", "watch it") to setOf("واتش ات"),
        setOf("spacetoon", "space toon") to setOf("سبيستون", "سبيس تون"),
        setOf("natgeo", "national geographic") to setOf("ناشيونال جيوغرافيك", "ناشونال جيوغرافيك"),
        setOf("sport", "sports") to setOf("سبورت", "رياضه", "رياضيه", "الرياضيه"),
        setOf("movie", "movies", "film", "cinema") to setOf("فيلم", "افلام", "سينما"),
        setOf("series", "drama") to setOf("مسلسل", "مسلسلات", "دراما"),
        setOf("kids", "cartoon") to setOf("اطفال", "كرتون", "انمي"),
        setOf("news") to setOf("اخبار", "الاخباريه", "اخباريه"),
        setOf("quran", "koran") to setOf("قران", "القران"),
        setOf("doc", "documentary") to setOf("وثائقي", "وثائقيه")
    )

    /**
     * Normalizes Arabic and English text for consistent indexing and comparison.
     */
    fun normalize(input: String): String {
        if (input.isBlank()) return ""
        val strippedMarks = input.replace(diacriticsAndMarksRegex, "")
        val sb = StringBuilder(strippedMarks.length)

        for (ch in strippedMarks.lowercase(Locale.ROOT)) {
            when (ch) {
                // Alef variants
                'أ', 'إ', 'آ', 'ٱ', 'ٲ', 'ٳ', 'ٵ' -> sb.append('ا')
                // Ta Marbuta & Ha variants
                'ة', 'ھ', 'ۀ', 'ۃ' -> sb.append('ه')
                // Ya / Alef Maqsura & Persian/Urdu Ya variants
                'ى', 'ی', 'ے', 'ې', 'ئ' -> sb.append('ي')
                // Waw with Hamza
                'ؤ' -> sb.append('و')
                // Kaf / Gaf variants
                'ک', 'گ', 'ڭ' -> sb.append('ك')
                // Persian/Kurdish consonant equivalents
                'پ' -> sb.append('ب')
                'چ' -> sb.append('ج')
                'ڤ', 'ڥ' -> sb.append('ف')
                'ژ' -> sb.append('ز')
                // Standalone Hamza (ء) -> space or omitted so "سماء" and "سما" or "جزء" and "جز" normalize cleanly
                'ء' -> {}
                // Arabic-Indic digits (٠-٩)
                in '\u0660'..'\u0669' -> sb.append((ch.code - 0x0660 + '0'.code).toChar())
                // Eastern Arabic / Persian digits (۰-۹)
                in '\u06F0'..'\u06F9' -> sb.append((ch.code - 0x06F0 + '0'.code).toChar())
                else -> sb.append(ch)
            }
        }

        val withSpaces = sb.toString()
            .replace(punctuationAndSeparatorsRegex, " ")
            .replace(scriptBoundaryRegex) { m ->
                val left = m.groupValues[1].ifEmpty { m.groupValues[3] }
                val right = m.groupValues[2].ifEmpty { m.groupValues[4] }
                "$left $right"
            }
            .replace(multiSpaceRegex, " ")
            .trim()

        return withSpaces
    }

    /**
     * Returns a spaceless normalized form to match compound words and queries with/without spaces
     * (e.g., "ابو ظبي" <-> "ابوظبي", "بي ان" <-> "بيان", "spider man" <-> "spiderman").
     */
    fun normalizeCompact(input: String): String {
        return normalize(input).replace(" ", "")
    }

    /**
     * Strips common Arabic definite article prefixes ("ال", "وال", "بال", "كال", "فال", "لل")
     * from a single normalized token when the remaining stem has at least 2 characters.
     */
    fun stripArabicDefiniteArticle(token: String): String {
        if (token.length < 4) return token
        return when {
            (token.startsWith("وال") || token.startsWith("بال") || token.startsWith("كال") || token.startsWith("فال")) && token.length >= 5 ->
                token.substring(3)
            (token.startsWith("ال") || token.startsWith("لل")) && token.length >= 4 ->
                token.substring(2)
            else -> token
        }
    }

    /**
     * Strips Arabic definite articles from all tokens in a normalized phrase.
     */
    fun normalizeWithoutDefiniteArticles(normalizedText: String): String {
        if (normalizedText.isEmpty()) return ""
        return normalizedText.split(' ')
            .filter { it.isNotEmpty() }
            .joinToString(" ") { stripArabicDefiniteArticle(it) }
    }

    /**
     * Normalizes common phonetic/spelling confusions in Arabic and collapses repeated characters
     * (e.g. ذ/ز/ظ -> ز, ض/ظ -> ض, س/ص -> س, ت/ط -> ت, ق/غ -> ق, "مميز"/"ممييز" -> "مميز").
     */
    fun normalizePhonetic(normalizedText: String): String {
        if (normalizedText.isEmpty()) return ""
        val sb = StringBuilder(normalizedText.length)
        var prevChar = '\u0000'
        for (ch in normalizedText) {
            val mapped = when (ch) {
                'ذ', 'ظ' -> 'ز'
                'ص' -> 'س'
                'ط' -> 'ت'
                'ض' -> 'د'
                'غ' -> 'ق'
                else -> ch
            }
            // Collapse consecutive duplicate letters (except digits like "11" or "2000")
            if (mapped != prevChar || mapped.isDigit() || mapped == ' ') {
                sb.append(mapped)
                prevChar = mapped
            }
        }
        return sb.toString().trim()
    }

    /**
     * Expands a normalized query with any matching bilingual IPTV aliases so searching "mbc"
     * also checks "ام بي سي", and searching "بي ان" also checks "bein".
     */
    fun expandQueryWithAliases(normalizedQuery: String): List<String> {
        if (normalizedQuery.isEmpty()) return emptyList()
        val variants = LinkedHashSet<String>()
        variants.add(normalizedQuery)

        for ((enSet, arSet) in bilingualAliases) {
            val matchesEn = enSet.any { alias ->
                normalizedQuery == alias || normalizedQuery.contains(alias)
            }
            val matchesAr = arSet.any { alias ->
                normalizedQuery == alias || normalizedQuery.contains(alias) ||
                    normalizeCompact(normalizedQuery).contains(alias.replace(" ", ""))
            }
            if (matchesEn) {
                for (enAlias in enSet) {
                    if (normalizedQuery.contains(enAlias)) {
                        for (arAlias in arSet) {
                            variants.add(normalizedQuery.replace(enAlias, arAlias).replace(multiSpaceRegex, " ").trim())
                        }
                    }
                }
            }
            if (matchesAr) {
                for (arAlias in arSet) {
                    if (normalizedQuery.contains(arAlias)) {
                        for (enAlias in enSet) {
                            variants.add(normalizedQuery.replace(arAlias, enAlias).replace(multiSpaceRegex, " ").trim())
                        }
                    }
                }
            }
        }
        return variants.toList()
    }

    /**
     * Computes bounded Damerau-Levenshtein edit distance (insertions, deletions, substitutions,
     * and adjacent transpositions) between [a] and [b], aborting early if distance exceeds [maxDistance].
     */
    fun boundedEditDistance(a: String, b: String, maxDistance: Int): Int {
        if (a == b) return 0
        val lenA = a.length
        val lenB = b.length
        if (kotlin.math.abs(lenA - lenB) > maxDistance) return maxDistance + 1
        if (lenA == 0) return lenB
        if (lenB == 0) return lenA

        var prevPrev = IntArray(lenB + 1)
        var prev = IntArray(lenB + 1) { it }
        var curr = IntArray(lenB + 1)

        for (i in 1..lenA) {
            curr[0] = i
            var minInRow = curr[0]
            val ca = a[i - 1]
            for (j in 1..lenB) {
                val cb = b[j - 1]
                val cost = if (ca == cb) 0 else 1
                var d = minOf(
                    prev[j] + 1,      // deletion
                    curr[j - 1] + 1,  // insertion
                    prev[j - 1] + cost // substitution
                )
                if (i > 1 && j > 1 && ca == b[j - 2] && a[i - 2] == cb) {
                    d = minOf(d, prevPrev[j - 2] + 1) // adjacent transposition
                }
                curr[j] = d
                if (d < minInRow) minInRow = d
            }
            if (minInRow > maxDistance) return maxDistance + 1
            val tmp = prevPrev
            prevPrev = prev
            prev = curr
            curr = tmp
        }
        return prev[lenB]
    }

    /**
     * Checks whether [queryToken] matches [candidateWord] within a small typo tolerance.
     */
    private fun isTypoTokenMatch(queryToken: String, candidateWord: String): Boolean {
        val qStem = stripArabicDefiniteArticle(queryToken)
        val cStem = stripArabicDefiniteArticle(candidateWord)
        val minLen = minOf(qStem.length, cStem.length)
        if (minLen < 4) return false

        val maxDist = if (minLen >= 8) 2 else 1
        if (boundedEditDistance(qStem, cStem, maxDist) <= maxDist) return true

        // Also allow prefix typo match if candidateWord is longer (e.g., query "الاختير" vs "الاختيارية")
        if (cStem.length > qStem.length) {
            val prefix = cStem.substring(0, qStem.length)
            if (boundedEditDistance(qStem, prefix, 1) <= 1) return true
        }
        return false
    }

    /**
     * Scores how well a candidate item ([targetTitle], [targetCategory]) matches [rawQuery].
     * Returns 0 if it does not match, or a positive relevance score (100..1100) where higher = better match.
     *
     * Priority Order:
     * 1. Exact Title Match (1000+)
     * 2. Title Starts-With / Prefix Match (820..920)
     * 3. Complete Word / Phrase Match in Title (680..780)
     * 4. Partial / Multi-Token Match in Title (450..620)
     * 5. Combined Title + Category or Bilingual Alias Match (340..440)
     * 6. Phonetic / Spelling Variation or Typo-Tolerant Match (180..300)
     */
    fun computeRelevanceScore(
        targetTitle: String,
        targetCategory: String,
        rawQuery: String,
        preNormalizedTitle: String? = null,
        preNormalizedCategory: String? = null
    ): Int {
        val normQ = normalize(rawQuery)
        if (normQ.isEmpty()) return 100

        val normTitle = preNormalizedTitle?.takeIf { it.isNotEmpty() } ?: normalize(targetTitle)
        val normCat = preNormalizedCategory ?: normalize(targetCategory)
        if (normTitle.isEmpty() && normCat.isEmpty()) return 0

        val lengthBonus = ((80 - normTitle.length.coerceAtMost(80)) / 4).coerceAtLeast(0)

        // 1. Direct Exact & Prefix Checks on Normalized Title
        if (normTitle == normQ) return 1050 + lengthBonus
        val compactQ = normQ.replace(" ", "")
        val compactTitle = normTitle.replace(" ", "")
        if (compactQ.isNotEmpty() && compactTitle == compactQ) return 1020 + lengthBonus

        val strippedQ = normalizeWithoutDefiniteArticles(normQ)
        val strippedTitle = normalizeWithoutDefiniteArticles(normTitle)
        if (strippedQ.isNotEmpty() && strippedTitle == strippedQ) return 980 + lengthBonus

        val strippedCompactQ = strippedQ.replace(" ", "")
        val strippedCompactTitle = strippedTitle.replace(" ", "")
        if (strippedCompactQ.isNotEmpty() && strippedCompactTitle == strippedCompactQ) return 960 + lengthBonus

        // 2. Starts-With / Prefix Match on Title
        if (normTitle.startsWith("$normQ ")) return 910 + lengthBonus
        if (normTitle.startsWith(normQ)) return 870 + lengthBonus
        if (strippedQ.isNotEmpty() && strippedTitle.startsWith("$strippedQ ")) return 850 + lengthBonus
        if (strippedQ.isNotEmpty() && strippedTitle.startsWith(strippedQ)) return 830 + lengthBonus
        if (compactQ.length >= 2 && compactTitle.startsWith(compactQ)) return 810 + lengthBonus
        if (strippedCompactQ.length >= 2 && strippedCompactTitle.startsWith(strippedCompactQ)) return 790 + lengthBonus

        // 3. Exact Word-Boundary Phrase Match inside Title
        if (" $normTitle ".contains(" $normQ ")) return 750 + lengthBonus
        if (strippedQ.isNotEmpty() && " $strippedTitle ".contains(" $strippedQ ")) return 720 + lengthBonus

        // 4. Contiguous Substring Match inside Title (with or without spaces)
        if (normTitle.contains(normQ)) return 660 + lengthBonus
        if (strippedQ.isNotEmpty() && strippedTitle.contains(strippedQ)) return 640 + lengthBonus
        if (compactQ.length >= 2 && compactTitle.contains(compactQ)) return 610 + lengthBonus
        if (strippedCompactQ.length >= 2 && strippedCompactTitle.contains(strippedCompactQ)) return 590 + lengthBonus

        // 5. Multi-Token Matching (All tokens in query must be satisfied)
        val qTokens = normQ.split(' ').filter { it.isNotEmpty() }
        val titleWords = normTitle.split(' ').filter { it.isNotEmpty() }
        val titleStems = titleWords.map { stripArabicDefiniteArticle(it) }
        val catWords = if (normCat.isNotEmpty()) normCat.split(' ').filter { it.isNotEmpty() } else emptyList()
        val combinedText = if (normCat.isNotEmpty()) "$normTitle $normCat" else normTitle
        val combinedCompact = combinedText.replace(" ", "")

        if (qTokens.size > 1) {
            // 5a. Check if all query tokens match inside Title (exact word, prefix, stem, or substring)
            var allInTitle = true
            var allWordOrPrefixInTitle = true
            var lastMatchedIndex = -1
            var inOrder = true

            for (qt in qTokens) {
                val qtStem = stripArabicDefiniteArticle(qt)
                var matchedWordIdx = -1
                var isWordOrPrefix = false

                for (idx in titleWords.indices) {
                    val tw = titleWords[idx]
                    val twStem = titleStems[idx]
                    if (tw == qt || twStem == qtStem || tw.startsWith(qt) || (qtStem.length >= 2 && twStem.startsWith(qtStem))) {
                        matchedWordIdx = idx
                        isWordOrPrefix = true
                        break
                    } else if (tw.contains(qt) || (qtStem.length >= 2 && twStem.contains(qtStem))) {
                        if (matchedWordIdx == -1) matchedWordIdx = idx
                    }
                }

                if (matchedWordIdx == -1) {
                    if (compactTitle.contains(qt) || (qtStem.length >= 2 && strippedCompactTitle.contains(qtStem))) {
                        isWordOrPrefix = false
                    } else {
                        allInTitle = false
                        break
                    }
                } else {
                    if (matchedWordIdx < lastMatchedIndex) inOrder = false
                    lastMatchedIndex = matchedWordIdx
                    if (!isWordOrPrefix) allWordOrPrefixInTitle = false
                }
            }

            if (allInTitle) {
                val base = if (allWordOrPrefixInTitle) 540 else 480
                val orderBonus = if (inOrder) 25 else 0
                return base + orderBonus + lengthBonus
            }
        }

        // 6. Check across Title + Category (e.g., user searches "افلام اكشن" or "قنوات رياضية" or "مسلسل رمضان")
        val allTokensInTitleOrCategory = qTokens.all { qt ->
            val qtStem = stripArabicDefiniteArticle(qt)
            combinedText.contains(qt) ||
                (qtStem.length >= 2 && (normTitle.contains(qtStem) || normCat.contains(qtStem))) ||
                combinedCompact.contains(qt)
        }
        if (allTokensInTitleOrCategory) {
            val catExactBonus = if (normCat == normQ || normCat.contains(normQ)) 30 else 0
            return 390 + catExactBonus + lengthBonus
        }

        // 7. Bilingual Alias Expansion Check (e.g., "mbc" <-> "ام بي سي", "bein" <-> "بي ان")
        val expandedQueries = expandQueryWithAliases(normQ)
        for (idx in 1 until expandedQueries.size) {
            val altQ = expandedQueries[idx]
            val altCompact = altQ.replace(" ", "")
            if (normTitle == altQ || compactTitle == altCompact) return 700 + lengthBonus
            if (normTitle.startsWith(altQ) || compactTitle.startsWith(altCompact)) return 620 + lengthBonus
            if (normTitle.contains(altQ) || compactTitle.contains(altCompact)) return 520 + lengthBonus
            if (combinedText.contains(altQ) || combinedCompact.contains(altCompact)) return 370 + lengthBonus
        }

        // 8. Phonetic Arabic Normalization Check (ذ/ز/ظ, ص/س, ط/ت, ض/د, collapsed repeated letters)
        val phoneticQ = normalizePhonetic(strippedQ.ifEmpty { normQ })
        if (phoneticQ.length >= 3) {
            val phoneticTitle = normalizePhonetic(strippedTitle.ifEmpty { normTitle })
            val phoneticCompactTitle = phoneticTitle.replace(" ", "")
            val phoneticCompactQ = phoneticQ.replace(" ", "")
            if (phoneticTitle == phoneticQ || phoneticCompactTitle == phoneticCompactQ) {
                return 340 + lengthBonus
            }
            if (phoneticTitle.contains(phoneticQ) || phoneticCompactTitle.contains(phoneticCompactQ)) {
                return 280 + lengthBonus
            }
            val pTokens = phoneticQ.split(' ').filter { it.isNotEmpty() }
            if (pTokens.isNotEmpty() && pTokens.all { pt -> phoneticTitle.contains(pt) }) {
                return 250 + lengthBonus
            }
        }

        // 9. Typo-Tolerant Fuzzy Token Matching (Damerau-Levenshtein distance <= 1..2 on tokens >= 4 chars)
        val allCandidates = if (catWords.isNotEmpty()) titleWords + catWords else titleWords
        if (qTokens.isNotEmpty() && allCandidates.isNotEmpty()) {
            var allMatchedWithTypo = true
            var atLeastOneInTitle = false
            for (qt in qTokens) {
                val qtStem = stripArabicDefiniteArticle(qt)
                val exactInTitle = normTitle.contains(qt) || (qtStem.length >= 2 && strippedTitle.contains(qtStem))
                val exactInCat = normCat.contains(qt) || (qtStem.length >= 2 && normCat.contains(qtStem))
                if (exactInTitle) {
                    atLeastOneInTitle = true
                    continue
                }
                if (exactInCat) {
                    continue
                }
                val typoInTitle = titleWords.any { tw -> isTypoTokenMatch(qt, tw) }
                if (typoInTitle) {
                    atLeastOneInTitle = true
                    continue
                }
                val typoInCat = catWords.any { cw -> isTypoTokenMatch(qt, cw) }
                if (!typoInCat) {
                    allMatchedWithTypo = false
                    break
                }
            }
            if (allMatchedWithTypo && atLeastOneInTitle) {
                return 190 + lengthBonus
            }
        }

        return 0
    }

    /**
     * Ranks, deduplicates, and returns all matching [IptvStreamItem] entries across
     * Live TV, Movies, TV Series, and Radio, ordered from highest relevance to lowest.
     */
    fun rankAndFilterStreams(
        candidates: List<IptvStreamItem>,
        rawQuery: String,
        contentTypeFilter: IptvContentType? = null,
        favoriteIds: Set<String> = emptySet(),
        maxResults: Int = 1500
    ): List<IptvStreamItem> {
        val filteredByType = if (contentTypeFilter == null) {
            candidates
        } else {
            candidates.filter { it.contentType == contentTypeFilter }
        }

        val normQ = normalize(rawQuery)
        if (normQ.isEmpty()) {
            return deduplicateStreamsForDisplay(filteredByType).take(maxResults)
        }

        data class ScoredStream(
            val item: IptvStreamItem,
            val score: Int
        )

        val scored = ArrayList<ScoredStream>(minOf(filteredByType.size, 512))
        for (item in filteredByType) {
            val baseScore = computeRelevanceScore(
                targetTitle = item.title,
                targetCategory = item.categoryName,
                rawQuery = rawQuery,
                preNormalizedTitle = item.normalizedTitle,
                preNormalizedCategory = item.normalizedCategory
            )
            if (baseScore > 0) {
                val favBonus = if (favoriteIds.contains(item.id)) 15 else 0
                scored.add(ScoredStream(item, baseScore + favBonus))
            }
        }

        scored.sortWith(
            Comparator { a, b ->
                val cmpScore = b.score.compareTo(a.score)
                if (cmpScore != 0) return@Comparator cmpScore
                val cmpLen = a.item.normalizedTitle.length.compareTo(b.item.normalizedTitle.length)
                if (cmpLen != 0) return@Comparator cmpLen
                val cmpType = a.item.contentType.ordinal.compareTo(b.item.contentType.ordinal)
                if (cmpType != 0) return@Comparator cmpType
                a.item.normalizedTitle.compareTo(b.item.normalizedTitle)
            }
        )

        val sortedItems = scored.map { it.item }
        return deduplicateStreamsForDisplay(sortedItems).take(maxResults)
    }

    /**
     * Ranks local [VideoItem] entries by relevance score so local video search also prioritizes
     * exact and prefix matches in Arabic and English.
     */
    fun rankAndFilterLocalVideos(
        videos: List<VideoItem>,
        rawQuery: String
    ): List<VideoItem> {
        val normQ = normalize(rawQuery)
        if (normQ.isEmpty()) return videos

        return videos.mapNotNull { video ->
            val score = computeRelevanceScore(video.title, video.folderName, rawQuery)
            if (score > 0) Pair(video, score) else null
        }.sortedWith(
            Comparator { a, b ->
                val c = b.second.compareTo(a.second)
                if (c != 0) c else a.first.title.length.compareTo(b.first.title.length)
            }
        ).map { it.first }
    }

    /**
     * Removes duplicate stream entries while preserving the highest-ranked occurrence.
     * - For SERIES: deduplicates by normalized series title/seriesId so multi-episode M3U series
     *   do not flood search results with 30 identical series cards.
     * - For LIVE_TV / MOVIES / RADIO: deduplicates by (contentType, streamUrl) and (contentType, normalizedTitle, categoryName).
     */
    fun deduplicateStreamsForDisplay(items: List<IptvStreamItem>): List<IptvStreamItem> {
        if (items.size <= 1) return items
        val out = ArrayList<IptvStreamItem>(items.size)
        val seenKeys = HashSet<String>(items.size)

        for (item in items) {
            val key = when (item.contentType) {
                IptvContentType.SERIES -> {
                    val sName = item.seriesName.ifBlank { item.title }
                    val normSeries = normalize(sName)
                    "SERIES_${item.sourceId}_${normSeries.ifEmpty { item.id }}"
                }
                else -> {
                    val urlKey = item.streamUrl.trim()
                    if (urlKey.isNotEmpty()) {
                        "${item.contentType.name}_${urlKey}"
                    } else {
                        "${item.contentType.name}_${item.normalizedTitle}_${item.normalizedCategory}"
                    }
                }
            }
            if (seenKeys.add(key)) {
                out.add(item)
            }
        }
        return out
    }
}
