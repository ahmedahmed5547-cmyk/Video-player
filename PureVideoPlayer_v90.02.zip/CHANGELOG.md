# Changelog — Pure Video Player (`com.pureplayer.video`)

All notable changes to **Pure Video Player** are documented in this file and organized by version.

## [v90.02] - 2026-11-17 (`versionCode = 9002`) — Google Play Compliance & Security Hardening
### Security & Google Play Policy Fixes
- **Trademark & Store Policy Compliance:** Replaced third-party trademark string `"IPTV Smarters Hub"` in English resources (`values/strings.xml`) with neutral `"IPTV Hub (Xtream & M3U)"` matching Arabic resources.
- **Self-Updater Bytecode Sanitization:** Removed `"application/vnd.android.package-archive"` package installer intent from `UpdateManager.kt` so the compiled DEX bytecode passes Google Play's Device and Network Abuse static scanner cleanly.
- **Subtitle Provider Policy Cleanup:** Removed third-party piracy domain references from `SubtitleSearchEngine.kt` and `SubtitleProviders.kt`, retaining compliant subtitle providers (`OpenSubtitles-v3`, `OpenSubtitles REST`, `Podnapisi`, `SubDL`).
- **Private Vault Backup & Cache Hardening:** Excluded `video_media_index_cache_v1.json`, `subtitles_cache`, and `demo_iptv_showcase.m3u8` from cloud backup and device transfer (`backup_rules.xml`, `data_extraction_rules.xml`), and filtered locked Private Vault folders out of the unencrypted local media index cache (`VideoIndexCache.kt`).
- **External Cast URI Safety (`FileProvider`):** Updated `PlayerActivity.beamVideoToExternalCastApp()` and `file_paths.xml` to wrap `file://` URIs via `FileProvider` (`content://`), preventing `FileUriExposedException` on Android 7.0+.
- **In-App Privacy & Data Security Disclosure:** Added a clear Privacy & Data Security summary card inside the About screen (`SettingsMenus.kt`) in both Arabic and English.

## [v90.01] - 2026-11-17 (`versionCode = 9001`) — Verified Green Build ✓
### Fixed & Improved
- Fixed Room `@Database` annotation syntax in `IptvDatabase.kt` (`exportSchema = false`).
- Upgraded `app/build.gradle.kts` keystore verification (`verifyKeystoreCredentials`) for full compatibility with Gradle 8.5 and Kotlin 1.9.22 DSL without inline lambda `break` errors.
- Updated `.github/workflows/build.yml` to automatically unpack `PureVideoPlayer*.zip`, sync `versionName`, run unit tests (`testGithubDebugUnitTest`, `testPlayDebugUnitTest`), and build signed Release APKs and Google Play AAB bundles.
- Preserved official signing key (`app/release.keystore`, alias `pureplayer_release_key`) for seamless in-place updates.

## [v36.2 – v38.05]
- Full-screen Settings & sub-menus with fluid staggered animations and About/Changelog screens.
- Integrated Room 2.6.1 + Paging 3.2.1 SQLite engine (`pure_video_iptv_room.db`) for Xtream Codes & M3U/M3U8 playlists.
- Added AES-256-GCM hardware-backed credential encryption (`IptvCredentialVault`) and `PBKDF2WithHmacSHA256` (`>= 100,000` iterations) Private Vault security.
- Added Cast Screen (Smart View / Miracast / DLNA), 5-Band Graphic Equalizer + 7 acoustic presets, and live `HW+` / `HW` / `SW` decoder switching.
