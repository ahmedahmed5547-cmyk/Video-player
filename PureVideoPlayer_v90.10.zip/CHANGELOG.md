# Changelog — VEXO Player: IPTV and Video player (`com.pureplayer.video`)

This Changelog permanently retains and displays **only the latest 3 versions** of **VEXO Player — IPTV and Video player**. When a new version is released, the new version is added at the top, the previous two versions are kept, and the oldest version is automatically removed.

## v90.10 (2026-11-18) — Google Play Console Release Bundle (`versionCode = 9010`)
- **Fresh Play Console Version Code:** Incremented `versionCode` to **`9010`** (`versionName = "90.10"`) to resolve the duplicate version code error in Google Play Console while preserving full Android 16 (`API 36`) compliance and embedded native debug symbols (`debugSymbolLevel = "FULL"`).
- **3-Version Rolling Changelog:** Retained strictly the latest 3 releases (`v90.10`, `v90.09`, and `v90.08`).

## v90.09 (2026-11-18) — Android 16 (API Level 36) Google Play Target SDK Compliance
- **Target API Level 36 Upgrade:** Upgraded `compileSdk` and `targetSdk` from `34` to **`36` (Android 16)** in `app/build.gradle.kts` to resolve the Google Play Console upload requirement (`API 36+`).
- **Native Debug Symbols & CI Compatibility:** Enabled `debugSymbolLevel = "FULL"` and `android.suppressUnsupportedCompileSdk=36` for clean GitHub Actions builds.
- **3-Version Rolling Changelog:** Retained strictly the latest 3 releases (`v90.09`, `v90.08`, and `v90.07`).

## v90.08 (2026-11-18) — Official `VEXO Player` (`IPTV and Video player`) Store Identity & Privacy Integration
- **Primary & Secondary App Identity:** Updated primary application name to **`VEXO Player`** with the secondary subtitle **`IPTV and Video player`** displayed directly underneath in the main toolbar, About dialog, and Google Play Store listing assets.
- **Official Developer Contact & Privacy Links:** Integrated developer contact email (`AHMEDAHMED5547@GMAIL.COM`) and official GitHub Privacy Policy URLs across all disclosures.
