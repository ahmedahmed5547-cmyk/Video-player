# Changelog — IPTV and Video player (`com.pureplayer.video`)

This Changelog permanently retains and displays **only the latest 3 versions** of **IPTV and Video player**. When a new version is released, the new version is added at the top, the previous two versions are kept, and the oldest version is automatically removed.

## [v90.07] - 2026-11-18 (`versionCode = 9007`) — Google Play Store Launch Readiness & Complete Branding
- **Complete Rebranding to `IPTV and Video player`:** Removed all remaining legacy references to the old name across download folders (`Movies/IPTV_and_Video_player`), `MediaSession` identifiers, string resources, Privacy Policy files, and Google Play Store graphic assets.
- **Google Play Store Final Verification:** Verified full compliance with Google Play policies (`play` flavor isolation with `ALLOW_DEMO_IPTV_SOURCE = false`, `ALLOW_SELF_UPDATE = false`, `ENABLE_IN_APP_UPDATER = false`, hardware-backed `AndroidKeyStore` encryption, cloud backup exclusion, and uncompressed native library alignment).

## [v90.06] - 2026-11-18 (`versionCode = 9006`) — Restore Stable Section-Specific Instant Search & 3-Version Changelog
- **Restored Original IPTV Search System:** Reverted the experimental `v90.05` search engine additions and restored the fast, stable search implementation (`IptvSearchNormalizer` + `IptvRepository.searchStreamsSql`) from the verified baseline.
- **Strict Section-Specific Search (`SectionScopedSearchHelper`):** Restricted IPTV search exclusively to the section currently being viewed — searching inside **Movies** returns only Movies, searching inside **TV Series** returns only TV Series, and searching inside **Live TV** returns only Live TV, never mixing results from other sections.
- **Instant Live Results While Typing:** Removed the `280ms` debounce delay and `distinctUntilChanged` bottleneck so search results update immediately from the very first character and with every subsequent keystroke without pressing Enter.
- **3-Version Rolling Changelog (`ChangelogVersionManager`):** Updated both the in-app Changelog (`SettingsMenus.kt`) and `CHANGELOG.md` to permanently retain and display only the latest 3 versions.

## [v90.05] - 2026-11-18 (`versionCode = 9005`) — Android Keyboard Viewport Resize & Layout Adjustment
- **On-Screen Keyboard Compatibility (`adjustResize` & `WindowInsetsCompat.Type.ime()`):** Configured `MainActivity` to dynamically adjust the results list bottom padding and viewport height when the Android keyboard opens or closes so search results are not hidden behind the keyboard.
