# Changelog — VEXO Player: IPTV and Video player (`com.pureplayer.video`)

This Changelog permanently retains and displays **only the latest 3 versions** of **VEXO Player — IPTV and Video player**. When a new version is released, the new version is added at the top, the previous two versions are kept, and the oldest version is automatically removed.

## v90.08 (2026-11-18) — Official `VEXO Player` (`IPTV and Video player`) Store Identity & Privacy Integration
- **Primary & Secondary App Identity:** Updated primary application name to **`VEXO Player`** with the secondary subtitle **`IPTV and Video player`** displayed directly underneath in the main toolbar, About dialog, and Google Play Store listing assets.
- **Official Developer Contact & Privacy Links:** Integrated developer contact email (`AHMEDAHMED5547@GMAIL.COM`) and official GitHub Privacy Policy URLs (`ahmedahmed5547-cmyk/Video-player`) across `PRIVACY_POLICY.md`, `privacy-policy.html`, in-app disclosures, and Play Console copy-paste materials.
- **3-Version Rolling Changelog:** Retained strictly the latest 3 releases (`v90.08`, `v90.07`, and `v90.06`).

## v90.07 (2026-11-18) — Google Play Store Readiness & Complete Brand Alignment
- **Complete Legacy Brand Purge:** Removed all remaining legacy references across download folders (`Movies/IPTV_and_Video_player`), `MediaSession` identifiers, string resources, Privacy Policy files, and Google Play Store graphic assets.
- **Google Play Policy Verification:** Verified full compliance with Google Play Developer Program Policies (`READ_MEDIA_VIDEO` core use-case declaration, hardware-backed `AndroidKeyStore` encryption, cloud backup exclusion, and zero third-party data collection).
- **Updated Store Upload Kit:** Regenerated all English promotional screenshots (`1080x1920` phone & `1920x1080` tablet), Feature Graphic (`1024x500`), and copy-paste texts.

## v90.06 (2026-11-18) — Restored Stable Section-Specific Instant Live Search & 3-Version Rolling Changelog
- **Restored Stable IPTV Search System:** Reverted the experimental search engine and restored the proven, fast, stable `IptvSearchNormalizer` + `IptvRepository.searchStreamsSql` search architecture.
- **Strict Current-Section Search Restriction (`SectionScopedSearchHelper`):** Restricted search exclusively to the currently viewed IPTV section (Movies searches only Movies, TV Series searches only TV Series, Live TV searches only Live TV).
- **Instant Live Search While Typing (`performInstantLiveSearch`):** Search results update immediately on the first character typed (`0ms` debounce delay) without pressing Enter or clicking a search button.
